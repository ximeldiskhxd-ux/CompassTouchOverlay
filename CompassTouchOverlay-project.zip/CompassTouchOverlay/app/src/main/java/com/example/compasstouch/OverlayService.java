package com.example.compasstouch;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;

public class OverlayService extends Service {
    private WindowManager wm;
    private WindowManager.LayoutParams bubbleLp;
    private View bubble;
    private View guide;
    private View panel;
    private int density;
    private int guideDistance = 320;
    private int guideWidth = 6;
    private boolean guideVisible = true;

    @Override
    public void onCreate() {
        super.onCreate();
        density = (int) getResources().getDisplayMetrics().density;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel("ct_overlay", "Compass Touch", NotificationManager.IMPORTANCE_LOW);
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
            Notification n = new Notification.Builder(this, "ct_overlay")
                    .setContentTitle("Compass Touch กำลังทำงาน")
                    .setContentText("ปุ่มลอยและเส้นไกด์พร้อมใช้งาน")
                    .setSmallIcon(android.R.drawable.ic_menu_compass)
                    .build();
            startForeground(7, n);
        }
        if (Settings.canDrawOverlays(this)) {
            addBubble();
            addGuide();
        }
    }

    private int dp(int v) { return Math.round(v * density); }

    private WindowManager.LayoutParams lp(int width, int height, int type, int flags) {
        int t = type;
        return new WindowManager.LayoutParams(width, height, t, flags, PixelFormat.TRANSLUCENT);
    }

    private void addBubble() {
        if (bubble != null) return;
        TextView b = new TextView(this);
        b.setText("CT");
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setGravity(Gravity.CENTER);
        b.setBackgroundColor(Color.rgb(155, 25, 35));
        bubble = b;
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        bubbleLp = lp(dp(52), dp(52), type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = dp(18);
        bubbleLp.y = dp(210);
        b.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY; long downTime;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY(); startX = bubbleLp.x; startY = bubbleLp.y; downTime = System.currentTimeMillis(); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    bubbleLp.x = startX + (int)(e.getRawX()-downX); bubbleLp.y = startY + (int)(e.getRawY()-downY); wm.updateViewLayout(bubble,bubbleLp); return true;
                }
                if (e.getAction() == MotionEvent.ACTION_UP) {
                    if (System.currentTimeMillis()-downTime < 220 && Math.abs(e.getRawX()-downX)<12 && Math.abs(e.getRawY()-downY)<12) showPanel();
                    return true;
                }
                return false;
            }
        });
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        wm.addView(b, bubbleLp);
    }

    private void addGuide() {
        GuideView g = new GuideView();
        guide = g;
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = lp(-1, -1, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        p.gravity = Gravity.TOP | Gravity.START;
        wm.addView(g, p);
    }

    private void showPanel() {
        if (panel != null) return;
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14),dp(14),dp(14),dp(14));
        root.setBackgroundColor(Color.rgb(18,19,22));

        TextView title = new TextView(this);
        title.setText("COMPASS TOUCH"); title.setTextColor(Color.WHITE); title.setTextSize(15); title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        root.addView(title);

        TextView desc = new TextView(this);
        desc.setText("เส้นไกด์ช่วยจำจุดลากด้วยมือ"); desc.setTextColor(Color.LTGRAY); desc.setTextSize(11); root.addView(desc);

        addSlider(root, "ระยะไกด์", 120, 700, guideDistance, v -> { guideDistance = v; if (guide != null) guide.invalidate(); });
        addSlider(root, "ความหนาเส้น", 2, 18, guideWidth, v -> { guideWidth = v; if (guide != null) guide.invalidate(); });

        Button toggle = new Button(this); toggle.setText(guideVisible ? "ซ่อนเส้นไกด์" : "แสดงเส้นไกด์"); toggle.setAllCaps(false);
        toggle.setOnClickListener(v -> { guideVisible = !guideVisible; toggle.setText(guideVisible ? "ซ่อนเส้นไกด์" : "แสดงเส้นไกด์"); if (guide != null) guide.invalidate(); });
        root.addView(toggle);

        Button close = new Button(this); close.setText("ปิด"); close.setAllCaps(false); close.setOnClickListener(v -> hidePanel()); root.addView(close);

        panel = root;
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams p = lp(dp(280), -2, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE);
        p.gravity = Gravity.TOP | Gravity.END; p.x = dp(12); p.y = dp(80);
        wm.addView(panel, p);
    }

    private interface ValueChange { void onChange(int v); }
    private void addSlider(LinearLayout root, String label, int min, int max, int value, ValueChange change) {
        TextView t = new TextView(this); t.setText(label+": "+value); t.setTextColor(Color.WHITE); t.setTextSize(11); root.addView(t);
        SeekBar s = new SeekBar(this); s.setMax(max-min); s.setProgress(value-min); s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar b,int p,boolean u){ int v=p+min; t.setText(label+": "+v); change.onChange(v); }
            public void onStartTrackingTouch(SeekBar b){} public void onStopTrackingTouch(SeekBar b){}
        }); root.addView(s);
    }

    private void hidePanel() { if (panel != null) { wm.removeView(panel); panel=null; } }

    @Override public int onStartCommand(Intent intent, int flags, int startId) { return START_STICKY; }

    @Override public void onDestroy() {
        hidePanel();
        if (guide != null) { wm.removeView(guide); guide=null; }
        if (bubble != null) { wm.removeView(bubble); bubble=null; }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private class GuideView extends View {
        private final android.graphics.Paint p = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG);
        GuideView() { super(OverlayService.this); p.setStrokeCap(android.graphics.Paint.Cap.ROUND); setWillNotDraw(false); }
        @Override protected void onDraw(android.graphics.Canvas c) {
            super.onDraw(c);
            if (!guideVisible) return;
            int w=getWidth(), h=getHeight();
            float x=w*0.5f, start=h*0.42f;
            float dist=Math.min(dp(guideDistance), h*0.42f);
            float end=start+dist;
            p.setColor(Color.argb(205,255,76,88)); p.setStrokeWidth(dp(guideWidth)); c.drawLine(x,start,x,end,p);
            p.setStyle(android.graphics.Paint.Style.FILL); p.setColor(Color.argb(230,255,76,88)); c.drawCircle(x,start,dp(11),p); c.drawCircle(x,end,dp(11),p);
            p.setColor(Color.WHITE); p.setTextSize(dp(11)); p.setTextAlign(android.graphics.Paint.Align.CENTER); c.drawText("เริ่ม",x,start-dp(18),p); c.drawText("ปล่อย",x,end+dp(24),p);
            p.setColor(Color.argb(70,255,255,255)); p.setStrokeWidth(dp(1)); c.drawLine(x-dp(34),start,x+dp(34),start,p); c.drawLine(x-dp(34),end,x+dp(34),end,p);
        }
    }
}
