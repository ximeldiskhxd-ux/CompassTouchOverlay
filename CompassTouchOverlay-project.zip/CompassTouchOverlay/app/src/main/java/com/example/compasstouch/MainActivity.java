package com.example.compasstouch;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private TextView status;
    private int density;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        density = (int) getResources().getDisplayMetrics().density;
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        updateStatus();
    }

    private int dp(int value) { return Math.round(value * density); }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        return b;
    }

    private GradientDrawable cardBg() {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.rgb(18, 19, 22));
        g.setCornerRadius(dp(16));
        g.setStroke(dp(1), Color.rgb(55, 57, 63));
        return g;
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(18), dp(18), dp(28));
        root.setBackgroundColor(Color.rgb(5, 6, 7));

        TextView title = text("COMPASS TOUCH", 26, Color.WHITE);
        title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, dp(44)));

        TextView sub = text("ตัวช่วยลากด้วยมือ + ปุ่มลอยบนเกม", 14, Color.LTGRAY);
        sub.setGravity(Gravity.CENTER);
        root.addView(sub, new LinearLayout.LayoutParams(-1, dp(36)));

        status = text("กำลังตรวจสอบสิทธิ์...", 14, Color.LTGRAY);
        status.setPadding(0, dp(8), 0, dp(12));
        root.addView(status);

        Button overlay = button("① อนุญาตแสดงทับแอปอื่น");
        overlay.setOnClickListener(v -> openOverlaySettings());
        root.addView(overlay, new LinearLayout.LayoutParams(-1, dp(52)));

        Button start = button("② เปิดตัวช่วยลอยบนหน้าจอ");
        start.setOnClickListener(v -> {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "เปิดสิทธิ์แสดงทับแอปอื่นก่อน", Toast.LENGTH_SHORT).show();
                openOverlaySettings();
                return;
            }
            Intent i = new Intent(this, OverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            Toast.makeText(this, "ตัวช่วยกำลังทำงาน", Toast.LENGTH_SHORT).show();
        });
        root.addView(start, new LinearLayout.LayoutParams(-1, dp(52)));

        Button freefire = button("③ เปิด Free Fire");
        freefire.setOnClickListener(v -> launchGame("com.dts.freefireth"));
        root.addView(freefire, new LinearLayout.LayoutParams(-1, dp(52)));

        Button max = button("④ เปิด Free Fire MAX");
        max.setOnClickListener(v -> launchGame("com.dts.freefiremax"));
        root.addView(max, new LinearLayout.LayoutParams(-1, dp(52)));

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(14), dp(14), dp(14), dp(14));
        info.setBackground(cardBg());
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1, -2);
        ip.topMargin = dp(16);
        root.addView(info, ip);

        info.addView(text("ตัวช่วยที่ทำงานจริง", 15, Color.WHITE));
        info.addView(text("• ปุ่มลอยอยู่เหนือเกม\n• เส้นไกด์แสดงจุดเริ่ม–จุดปล่อยสำหรับการลากด้วยนิ้ว\n• ปรับระยะ / ความเร็วเป้าหมาย / ขนาดเส้นได้\n• สัมผัสเกมยังเป็นการควบคุมด้วยมือของคุณเอง\n• ไม่ล็อกเป้า ไม่ยิง และไม่ส่ง gesture เข้าเกม", 13, Color.LTGRAY));

        TextView note = text("หมายเหตุ: Android ไม่อนุญาตให้เว็บเปลี่ยน sensitivity ของเกมโดยตรง ตัวแอปนี้จึงช่วยด้วย overlay และคู่มือการลากที่มองเห็นขณะเล่น", 12, Color.GRAY);
        note.setPadding(0, dp(14), 0, 0);
        root.addView(note);

        setContentView(root);
        updateStatus();
    }

    private void updateStatus() {
        if (Settings.canDrawOverlays(this)) {
            status.setText("สถานะ: พร้อมใช้งาน ✓");
            status.setTextColor(Color.rgb(110, 235, 140));
        } else {
            status.setText("สถานะ: ยังไม่ได้อนุญาตแสดงทับแอปอื่น");
            status.setTextColor(Color.rgb(255, 112, 112));
        }
    }

    private void openOverlaySettings() {
        Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:" + getPackageName()));
        startActivity(intent);
    }

    private void launchGame(String packageName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch == null) {
            Toast.makeText(this, "ยังไม่พบเกมนี้ในเครื่อง", Toast.LENGTH_SHORT).show();
            return;
        }
        startActivity(launch);
    }
}
